/* start set questions and answers here */
const Qns_grp = [
 {
    question: "India is a part of which continent?",
    answers: [
    {text: "Europe", correct: false},
    {text:"Asia", correct: true},
    {text:"Africa", correct: false},
    {text:"North America", correct: false},
    ]
 },
 {
    question: "Name the only desert in India.?",
    answers: [
    {text:"Thar Desert", correct:true},
    {text:"Gibson Desert ", correct:false},
    {text:"Atacama Desert", correct:false},
    {text:"Patagonian Desert", correct:false},
    ] 
 },
 {
    question: "Which is the deepest ocean in the world?",
    answers: [
    {text:"Indian Ocean", correct:false},
    {text:"Atlantic", correct:false},
    {text:"Southern (Antarctic)", correct:false},
    {text:"Pacific Ocean", correct:true},
    ] 
 },
 {
    question: "Which is the tallest mountain in the world?",
    answers: [
    {text:"Lhotse mountain", correct:false},
    {text:"Mount Everest mountain", correct:true},
    {text:"Cho Oyu mountain", correct:false},
    {text:"Makalu mountain", correct:false},
    ]  
 }, 
 {
   question: "How many continents are there in the world?",
    answers: [
    {text:"Twenty One", correct:false},
    {text:"Seven", correct:true},
    {text:"Fifty One", correct:false},
    {text:"One Zero One", correct:false},
    ]  
 } 
];
/* end set questions and answers here */

/* start set variables for three elements qsn and answer-buttons and next-btn which asssign in html file */
const questionElement = document.getElementById("qsn");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
/* end set variable here */

let currentQuestionIndex = 0;
let score = 0;

/* Start Quize With First Question */
function startQuiz(){
   currentQuestionIndex = 0;
    score=0;
    nextButton.innerHTML="Next";
    showQuestion();
    }
/* Showquestion function here */

function showQuestion(){
resetState();
let currentQuestion = Qns_grp[currentQuestionIndex];
let questionNo = currentQuestionIndex + 1;
questionElement.innerHTML=questionNo + ". " + currentQuestion.
question;

/* Show answers code here */
currentQuestion.answers.forEach(answer=>{
    const button=document.createElement("button");
    button.innerHTML=answer.text;
    button.classList.add("btn");
    answerButtons.appendChild(button);
    if(answer.correct){
      button.dataset.correct=answer.correct;
      
    }
        button.addEventListener("click",selectAnswer);
});

}
/* Remove hide first answerbuttons here */
function resetState(){
   nextButton.style.display="none";
   while(answerButtons.firstChild){
      answerButtons.removeChild(answerButtons.firstChild);
   }   
  }

  function selectAnswer(e){
const selectedBtn=e.target;
const isCorrect=selectedBtn.dataset.correct==="true";
if(isCorrect){
   selectedBtn.classList.add("correct");
   score++;
   }else{
      selectedBtn.classList.add("incorrect");
   }
Array.from(answerButtons.children).forEach(button=>{
if(button.dataset.correct==="true"){
   button.classList.add("correct");
}
button.disabled=true;
});
nextButton.style.display="block";
  }
function showScore(){
   resetState();
   questionElement.innerHTML=`You scored ${score} out of ${Qns_grp.length}!`;
   nextButton.innerHTML="Play Again";
   nextButton.style.display="block";
}

function handleNextButton(){
  currentQuestionIndex++;
  if(currentQuestionIndex<Qns_grp.length){
   showQuestion();
  }else{
   showScore();
  } 
}




nextButton.addEventListener("click",()=>{
   if(currentQuestionIndex<Qns_grp.length){
      handleNextButton();
   }else{
      startQuiz();
   }
});




  startQuiz();