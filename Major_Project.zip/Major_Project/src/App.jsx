import React from 'react';
import "./App.css";

import Weather from './components/Weather';
import ButtonAppBar from './components/ButtonAppBar';
import Subscriber from './components/Subscriber';
import TemporaryDrawer from './components/TemporaryDrawer';
import Signin from './components/Signin'
import { BrowserRouter as Router,Routes,Route } from "react-router-dom"
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
 
const App = () => {
  return (
     <Container className="p-3">
       <Container className="p-3 mb-3 bg-success rounded-3">
    <Router>
   <div className="App">
<ButtonAppBar></ButtonAppBar>
     <Routes>
      <Route path="/subscriber" element={<Subscriber />}/>
      <Route path="/Weather" element={<Weather />}/>
      <Route path="/Signin" element={<Signin />}/>
     </Routes>
        </div>
      </Router>
      </Container>
      </Container>
  );
}

export default App;
