import React,{useState} from "react";
import "./Signin.css"
import { TextField } from "@mui/material";
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import  Button  from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import { useNavigate } from "react-router-dom";


const Signin = () => {
  const navigate = useNavigate();
   const[input,setInput]=useState({
        email:"",
        password:"",
     });
const handleLogin = (e)=>{
  e.preventDefault();
  const loggeduser = JSON.parse(localStorage.getItem("user"));
  if(input.email===loggeduser.email && 
    input.password===loggeduser.password
  ) {
    navigate("/");
  }else{
    alert("wrong email or password");
  }
};
  return (
    <form onSubmit={handleLogin}>
    <Container className="p-3">
      <Container className="p-3 mb-3 bg-dark rounded-3">
    <div className="sinone">
    <div className="sintwo">
       <h1 style={{color:"red"}}>Login</h1>
        <div style={{
display:"flex",
alignItems:"center",
justifyContent:"center",
height:"40vh",
        }}>
      <div className="mb-3">
     <TextField 
     id="outlined-basic" 
     label="Email" 
     variant="outlined"
     type="email"
     name="email" 
     value={input.email}
     onChange={(e)=>
setInput({
   ...input,
   [e.target.name]: e.target.value,
})
}
     style={{width:"300px",marginTop:"-18%"}}
  
    
sx={{
".MuiInputLabel-root":{
  color:"red",
  fontSize:"15px",
},

".MuiOutlinedInput-root":{
  input:{
  fontFamily:"monospace",
  color:"chocolate",
  fontSize:"18px"
},
fieldset:{
  border:"3px solid darkgreen"
},
"&.Mui-focused fieldset":{
   border:"3px solid darkgreen"
},

  },

}}
/>
</div>
 </div>
 <div className="mb-3">
 <TextField 
 type='password'
 name="password"
value={input.password}
onChange={(e)=>
setInput({
   ...input,
   [e.target.name]:e.target.value,
})
}
      id="standard-adornment-password" 
     label="Password" 
     variant="outlined"
     style={{width:"300px",marginTop:"-35%",marginLeft:"8%"}}
  
    
sx={{
".MuiInputLabel-root":{
  color:"red",
  fontSize:"15px",
},

".MuiOutlinedInput-root":{
  input:{
  fontFamily:"monospace",
  color:"chocolate",
  fontSize:"18px"
},
fieldset:{
  border:"3px solid darkgreen"
},
"&.Mui-focused fieldset":{
   border:"3px solid darkgreen"
},

  },

}}
/>
</div>
<div className="mb-3">
 <FormControlLabel control={<Checkbox  />} label="New Subscriber" id='chk1' />
 <FormControlLabel control={<Checkbox  />} label="Forget Password" id='chk2' />
 </div>
 <div className="mb-3">
  <Button variant="primary" className='loginbtn' onClick={handleLogin}>Submit</Button>     
  </div>
    
        </div>   
    </div>
    </Container>
   </Container>
     </form>
  );
}

export default Signin; 



