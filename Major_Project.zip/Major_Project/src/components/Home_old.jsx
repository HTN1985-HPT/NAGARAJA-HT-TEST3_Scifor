import React from 'react';


import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
 
const Home = () => {
  return (
     <Container className="p-3">
       <Container className="p-3 mb-3 bg-success rounded-3">
   
   <div className="home">
  
   <h1>Home page</h1>
        </div>
     
      </Container>
      </Container>
  );
}

export default Home;
