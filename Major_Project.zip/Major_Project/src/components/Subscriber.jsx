import React,{useState} from "react";
import { useNavigate } from "react-router-dom";
import "./fstyle.css";
import { Password } from "@mui/icons-material";
const Subscriber =() => {
   const navigate=useNavigate();
   const[input,setInput]=useState({
      name:"",
      email:"",
      password:"",
   });

   // to store value in localstorage
const handleSubmit =(e)=>{
   e.preventDefault();
   localStorage.setItem("user",JSON.stringify(input));
   navigate("/signin");
};
   return(
      <>
          <div className="container">
      <form onSubmit={handleSubmit}>
         <h1>New Subscriber</h1>
<div className="mb-3">
<label htmlFor="name" className="form-label">Name</label>
<input 
type="text" 
name="name" 
value={input.name} 
onChange={(e)=>
setInput({
   ...input,
   [e.target.name]: e.target.value,
})
}
className="form-control" 
id="form3Example1cg" required />
</div>

<div className="mb-3">
<label htmlFor="email" className="form-label">Email</label>
<input 
name="email" 
value={input.email} 
onChange={(e)=>
setInput({
   ...input,
   [e.target.name]: e.target.value,
})
}
type="email"
className="form-control"
 id="form3Example1cg" required/>
</div>

<div className="mb-3">
<label htmlFor="password" className="form-label">Password</label>
<input 
type="password" 
name="password"
value={input.password}
onChange={(e)=>
setInput({
   ...input,
   [e.target.name]:e.target.value,
})
}
className="form-control" 
id="form3Example1cg" required/>
</div>

<div className="mb-3">
<label htmlFor="cpassword" className="form-label">Confirm Password</label>
<input type="password" className="form-control" id="cpassword" required/>
</div>

<button type="submit" className="btn btn-primary" onClick={handleSubmit}>Submit</button>
      </form>
    </div>
    </>
   ); 
}

export default Subscriber;