// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
//import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCBxZnb1KtkzybTLeABpfqI6rY2KTRgJtg",
  authDomain: "users-211c7.firebaseapp.com",
  projectId: "users-211c7",
  storageBucket: "users-211c7.firebasestorage.app",
  messagingSenderId: "872577207926",
  appId: "1:872577207926:web:4870135c97787970265957",
  measurementId: "G-5M17NBEKZR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
//const analytics = getAnalytics(app);
export const auth = getAuth(app)